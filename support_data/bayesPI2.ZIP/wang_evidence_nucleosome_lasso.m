function [net, gamma, logev] = wang_evidence_nucleosome_lasso(net, x, t, nucleosome_t,num)
global isnucleosome
%EVIDENCE Re-estimate hyperparameters using evidence approximation.
%
%	Description
%	[NET] = EVIDENCE(NET, X, T) re-estimates the hyperparameters ALPHA
%	and BETA by applying Bayesian re-estimation formulae for NUM
%	iterations. The hyperparameter ALPHA can be a simple scalar
%	associated with an isotropic prior on the weights, or can be a vector
%	in which each component is associated with a group of weights as
%	defined by the INDEX matrix in the NET data structure. These more
%	complex priors can be set up for an MLP using MLPPRIOR. Initial
%	values for the iterative re-estimation are taken from the network
%	data structure NET passed as an input argument, while the return
%	argument NET contains the re-estimated values.
%
%	[NET, GAMMA, LOGEV] = EVIDENCE(NET, X, T, NUM) allows the re-
%	estimation  formula to be applied for NUM cycles in which the re-
%	estimated values for the hyperparameters from each cycle are used to
%	re-evaluate the Hessian matrix for the next cycle.  The return value
%	GAMMA is the number of well-determined parameters and LOGEV is the
%	log of the evidence.
%
%	See also
%	MLPPRIOR, NETGRAD, NETHESS, DEMEV1, DEMARD
%
%	Copyright (c) Ian T Nabney (1996-2001)
% This is a modification of original evidence.m by Junbai Wang May 2007
%

errstring = consist(net, '', x, t);
if ~isempty(errstring)
  error(errstring);
end

ndata = size(x, 1);
if nargin == 3
  num = 1;
end

% Extract weights from network
w = wang_netpak(net);

% Evaluate data-dependent contribution to the Hessian matrix.
%[h, dh] = wang_nethess_lasso(w, net, x, t,nucleosome_t);

clear h;  % To save memory when Hessian is large
if (~isfield(net, 'beta'))
  local_beta = 1;
end

%e is total error, edata is data error E_D, eprior is weight error E_w
[e, edata, eprior] = wang_neterr_lasso(w, net, x, t,nucleosome_t);

% Do the re-estimation.
ngroups=size(net.alpha,1);
%for k=1:num
    %Restimate alpha and beta
    if ngroups==1
        net.alpha=length(w)/eprior;
        logev = length(w)*log(net.alpha);
    else
        for m=1:ngroups
            group_nweights=sum(net.index(:,m));
            net.alpha(m)=group_nweights/eprior(m);
            % Weight alphas by number of weights in group
            logas(m) = group_nweights*log(net.alpha(m));
        end
        logev = sum(logas);
    end
    if isfield(net, 'beta')
      gamma=length(w);
      net.beta = real(0.5*(net.nout*ndata - gamma)/edata);  
      logev = logev + 0.5*ndata*log(net.beta) - 0.5*ndata*log(2*pi)-gamma*0.5*log(net.beta);
      local_beta = net.beta;
    end
    
     % Evaluate new log evidence
    e = wang_errbayes_lasso(net, edata);
    if size(net.alpha) == [1 1]
        logev = logev - e - 0.5*sum(log(local_beta+net.alpha));
    else
        for m = 1:ngroups  
            logev = logev - e - ...
                    0.5*sum(log(local_beta*net.index(:, m)+...	%removing two coupling terms
                net.alpha(m)));
        end
    end
%end




function net = wang_mlp(nin, nhidden, nout, outfunc, prior, beta,N,L,each_seq_len,med_N,seed,isnucleosome)
%MLP	Create a 2-layer feedforward network.
%
%	Description
%	NET = MLP(NIN, NHIDDEN, NOUT, FUNC) takes the number of inputs,
%	hidden units and output units for a 2-layer feed-forward network,
%	together with a string FUNC which specifies the output unit
%	activation function, and returns a data structure NET. The weights
%	are drawn from a zero mean, unit variance isotropic Gaussian, with
%	varianced scaled by the fan-in of the hidden or output units as
%	appropriate. This makes use of the Matlab function RANDN and so the
%	seed for the random weight initialization can be  set using
%	RANDN('STATE', S) where S is the seed value.  The hidden units use
%	the TANH activation function.
%
%	The fields in NET are
%	  type = 'mlp'
%	  nin = number of inputs
%	  nhidden = number of hidden units
%	  nout = number of outputs
%	  nwts = total number of weights and biases
%	  actfn = string describing the output unit activation function:
%	      'linear'
%	      'logistic
%	      'softmax'
%	  w1 = first-layer weight matrix
%	  b1 = first-layer bias vector
%	  w2 = second-layer weight matrix
%	  b2 = second-layer bias vector
%	 Here W1 has dimensions NIN times NHIDDEN, B1 has dimensions 1 times
%	NHIDDEN, W2 has dimensions NHIDDEN times NOUT, and B2 has dimensions
%	1 times NOUT.
%
%	NET = MLP(NIN, NHIDDEN, NOUT, FUNC, PRIOR), in which PRIOR is a
%	scalar, allows the field NET.ALPHA in the data structure NET to be
%	set, corresponding to a zero-mean isotropic Gaussian prior with
%	inverse variance with value PRIOR. Alternatively, PRIOR can consist
%	of a data structure with fields ALPHA and INDEX, allowing individual
%	Gaussian priors to be set over groups of weights in the network. Here
%	ALPHA is a column vector in which each element corresponds to a
%	separate group of weights, which need not be mutually exclusive.  The
%	membership of the groups is defined by the matrix INDX in which the
%	columns correspond to the elements of ALPHA. Each column has one
%	element for each weight in the matrix, in the order defined by the
%	function MLPPAK, and each element is 1 or 0 according to whether the
%	weight is a member of the corresponding group or not. A utility
%	function MLPPRIOR is provided to help in setting up the PRIOR data
%	structure.
%
%	NET = MLP(NIN, NHIDDEN, NOUT, FUNC, PRIOR, BETA) also sets the
%	additional field NET.BETA in the data structure NET, where beta
%	corresponds to the inverse noise variance.
%
%	See also
%	MLPPRIOR, MLPPAK, MLPUNPAK, MLPFWD, MLPERR, MLPBKP, MLPGRAD
%
%	Copyright (c) Ian T Nabney (1996-2001)
% This is a modificaiton of original mlp.m by Junbai Wang May 2007
%

randn('state',0); %ceil(abs(randn)*100));
rand('state',0);  %ceil(abs(randn)*100));

net.type = 'mlp';
net.nin = nin;  %here we assume nin =N-L+1
net.nhidden = nhidden;
net.nout = nout;

%added wang
if isnucleosome
    net.nwts=4*L*nhidden+nhidden+(nhidden)*nout+1+1*nhidden; % number of weights 
else
     net.nwts=4*L*nhidden+nhidden+(nhidden)*nout+1;
end
    %here plus one parameter for nucleosome density Oct08!
%end added

outfns = {'linear', 'logistic', 'softmax'};

if sum(strcmp(outfunc, outfns)) == 0
  error('Undefined output function. Exiting.');
else
  net.outfn = outfunc;
end

if nargin > 4
  if isstruct(prior)
    net.alpha = prior.alpha;
    net.index = prior.index;
  elseif size(prior) == [1 1]
    net.alpha = prior;
  else
    error('prior must be a scalar or a structure');
  end  
end

%added wang 
%we assuem nin=1, med_N=50
med_N=4*L; %*nhidden; %50;
if isempty(seed)
    if isnucleosome
	    net.w1=ones(4*L+1,nhidden)*1.0+randn(4*L+1, nhidden)/sqrt(4*L+1 + 1)*10e-1;
    else
        %net.w1=randn(4*L, nhidden)/sqrt(4*L+1);
	net.w1=ones(4*L,nhidden)*1.0+randn(4*L, nhidden)/sqrt(4*L+1)*10e-1;
	%normalize the total weight to 40 added Aug 2009
	norm_fact=sum(sum(abs(net.w1)))/40;
	net.w1=net.w1/norm_fact;
	%net.w1=net.w1*10e-2; %added aug 2009
    end
        %here plus one parameter for nucleosome density Oct08!
    %	net.w1=randn(4*L, nhidden)/sqrt(med_N + 1);
	net.seed=[];
else
	net.w1=consensus2matrix(seed)+0.5;
	net.seed=seed;
end
%end added
isdefault=1;
if isempty(seed) 
    if isdefault==1
	    if isnucleosome
            net.b1 =repmat(-0.1,1,nhidden)+randn(1, nhidden)/sqrt(4*L +1 + 1)*10e-3;  %randn(1, nhidden)/sqrt(4*L + 1); %*10e-5;
        else
            net.b1 =repmat(-0.1,1,nhidden)+randn(1, nhidden)/sqrt(4*L +1)*10e-3;
	 %   net.b1=net.b1*10e-4; %added aug 2009	     
        end
    	net.w2 =repmat(0.55,nhidden,1)+randn(nhidden, nout)/sqrt(nhidden + 1)*10e-3; %1/mean(each_seq_len)/2; %randn(nhidden, nout)/sqrt(nhidden + 1);
	net.b2 =repmat(0.5,1,1);  %randn(1, nout)/sqrt(nhidden + 1); %1/mean(each_seq_len)/2; %randn(1, nout)/sqrt(nhidden + 1);
	%net.b2=net.b2*10e-4;	%added aug 2009
    else
        if isnucleosome
	        net.b1 =randn(1, nhidden)/sqrt(4*L + 1+1);
        else
            net.b1 =randn(1, nhidden)/sqrt(4*L + 1);
        end
        net.w2 =randn(nhidden, nout)/sqrt(nhidden + 1);
        net.b2 =randn(1, nout)/sqrt(nhidden + 1);
     end

else
	net.w2=0.52; %repmat(0.55,nhidden,1)+randn(nhidden, nout)/sqrt(nhidden + 1)*10e-5;
	net.b1=-0.1; %repmat(-0.1,1,nhidden)+randn(1, nhidden)/sqrt(4*L +1)*10e-5;
	net.b2=0.5; %repmat(0.5,1,1)*10e-3;
%	net.w2=5;
%	net.b2=1;
end

net.motif_L=L;
net.sequence_L=N;
net.med_sequence_L=med_N;
if ~isempty(each_seq_len)
	net.each_seq_len=each_seq_len;
end
%added wang
net.beta = beta;

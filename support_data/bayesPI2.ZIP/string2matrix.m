function w=string2matrix(str)
%transform string to weight matrix representation
%
chars = {'a', 'c', 'g', 't'};
w=zeros(4,length(str));

for i=1:4
 idx_s=findstr(chars{i},lower(str));
 w(i,idx_s)=1;
end
w=reshape(w,prod(size(w)),1);

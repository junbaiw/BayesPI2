function [cases,cases_m]=least_makeSequence(seq_length,num_of_genes,motif,motif_code,geneExp)
%make sequence for gene and insert motif
%seq_length=20;
T=seq_length;
ntrain=num_of_genes;
chars = ['a', 'c', 'g', 't'];

cases = cell(1, ntrain);
background_dist = normalise(ones(1, length(chars)));

unif_pos = normalise(ones(1, T-length(motif)));
cases = cell(1, ntrain);
data = zeros(1,T);
for i=1:ntrain
  data = sample_discrete(background_dist, 1, T);
  L = sample_discrete(unif_pos, 1, 1);
  if (geneExp(i)>0 & ~isempty(motif) & ~isempty(motif_code))       %only add motif to possiative ratios and motif is not empty
    data(L:L+length(motif)-1) = motif_code;
  end
  cases{i} = data;
  cases_m(i,:)=data;
  i	
end



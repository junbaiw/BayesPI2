function [N,nin,nhidden,nout,aw1,ab1,aw2,ab2,beta,x_binary,each_seq_len,...
    nouter,ninner,options,record_net,all_loop,coupling,med_N,out_string]=BayesPI_setParameters(x,isrepeat,out_fold,fileexp,L,nhidden,alphaClass)
%global alphaClass
% Set up network parameters.
med_N=median(sum(x>0,2));    %
N=size(x,2);  %sequence length
%L=8;    %motif length plus 2 flank region in each site
nin = N*4;			% Number of sequence base times 4.
if isempty(nhidden)
	nhidden=1;			% Number of hidden units.
end
nout = 1;	                % Number of outputs.
if alphaClass<=4
    aw1 = 0.01; %repmat( 0.01,1,L);         %*ones(1, nin);	% First-layer ARD hyperparameters.
    ab1 = 0.01;			% Hyperparameter for hidden unit biases.
    aw2 = 0.01;			% Hyperparameter for second-layer weights.
    ab2 = 0.01;			% Hyperparameter for output unit biases.    
else
    if length(L)>1 & alphaClass>4
        for i=1:length(L)
            aw1{i}=repmat(0.01,1,L(i));
        end
    else
        aw1=repmat(0.01,1,L);   %here we set ecah position has a hyperparameter.
    end
    ab1 = 0.01;			% Hyperparameter for hidden unit biases.
    aw2 = 0.01;			% Hyperparameter for second-layer weights.
    ab2 = 0.01;			% Hyperparameter for output unit biases.
end

%a_w2b2=0.01;        %here we set the second-layer weights and its output unit biase share the same 
                    %Haperparameter aw2==ab2
                   
coupling =[ ];		% add 2 Hyperparameter for coupling weight in W1
beta =50;	%0.01		% Coefficient of data error.

%transform sequence x to binary representation of sequence For example,
%A=[ACGT -> 1000],C=[ACGT -> 0100],G=[ACGT -> 0010],T=[ACGT -> 0001],
%transform x to sequence index,
x_binary=sequence2binary(x,isrepeat);
if ~isrepeat
	each_seq_len=sum(x_binary,2);
else
	for ii=1:size(x,1)
		each_seq_len(ii)=max(find(x(ii,:)>0));
		if each_seq_len(ii)<=L(1)
			disp('Sequence length < motif L!')
			each_seq_len(ii),ii
		end
	end
end
clear x t0 %for saving memory

% Set up vector of options for the optimiser.
nouter = 5;			% Number of outer loops
ninner = 10;		        % Number of inner loops
options = zeros(1,18);		% Default options vector.
options(1) = 0;			% This provides display of error values.
options(2) = 1.0e-7;	% This ensures that convergence must occur
options(3) = 1.0e-7;
options(14) = 500;		% Number of training cycles in inner loop. 
%options(9)=1; 	%check gradient
%net.motif_counts=motif_counts;

%start to do motif search
record_net=[];
all_loop=1;
disp('Start to compute PWM ....')
out_string=['save ', out_fold,'/',fileexp,'_mlpout_motifL',num2str(min(L)),'_',num2str(max(L)),'.mat']

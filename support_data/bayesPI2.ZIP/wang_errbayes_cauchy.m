function [e, edata, eprior] = wang_errbayes_cauchy(net, edata)
%ERRBAYES Evaluate Bayesian error function for network.
%
%	Description
%	E = ERRBAYES(NET, EDATA) takes a network data structure  NET together
%	the data contribution to the error for a set of inputs and targets.
%	It returns the regularised error using any zero mean Gaussian priors
%	on the weights defined in NET.
%
%	[E, EDATA, EPRIOR] = ERRBAYES(NET, X, T) additionally returns the
%	data and prior components of the error.
%
%	See also
%	GLMERR, MLPERR, RBFERR
%
%	Copyright (c) Ian T Nabney (1996-2001)
%This is a modificationof the orignal errbayes.m by junbai wang May 2007
%

% Evaluate the data contribution to the error.
if isfield(net, 'beta')
  e1 = net.beta*edata;
else
  e1 = edata;
end

% Evaluate the prior contribution to the error.
if isfield(net, 'alpha')
   w = wang_netpak(net);
   if size(net.alpha) == [1 1]
      eprior = sum(1./net.alpha*log(1+net.alpha^2*w.^2));   %sum(abs(w));  %0.5*(w*w');
      eprior=eprior+eps.*(eprior<eps);
      e2 = eprior*net.alpha;
  else
      if (isfield(net, 'mask'))
         nindx_cols = size(net.index, 2);
         nmask_rows = size(find(net.mask), 1);
         index = reshape(net.index(logical(repmat(net.mask, ...
            1, nindx_cols))), nmask_rows, nindx_cols);
      else
         index = net.index;
      end
      eprior =((1./(index*net.alpha)).*log(1+(index*net.alpha.^2).*w'.^2))'*index; %abs(w)*index;    %0.5*(w.^2)*index;
      %to avoid zeros
      eprior=eprior+eps.*(eprior<eps);
      e2 = eprior*net.alpha; 
   end
else
  eprior = 0;
  e2 = 0;
end

e = e1 + e2;


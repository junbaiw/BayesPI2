function [STATS]=simple_regression(x,y)
%simple linear regression function Y=X*B
%all formulars are based on below site
%
%%http://www.gseis.ucla.edu/courses/ed231a1/notes2/slr0.html
%regress(y',x')
%in: x is pxn matrics, y is 1xn vector,
%out: regression model fit F statistic--F and P value--P
%regression coefficient--B, T value to regression coefficient -- T
%r square statistics --R2, intercepte is the first row of B
%
%present simple regression only support one x variable!
%Author: Junbai Wang , Oct 05 2008
M=x';
E=y';

%below we use svd to solve linear regression
%E=MA
[u,s,v]=svd(M);
old_A=v*pinv(s'*s)*s'*u'*E;
fit_coefficient=old_A ;
%the first column of x and fit_coefficient is a constant --intercepte
fit_y=M*old_A;

%below formular from
%http://www.gseis.ucla.edu/courses/ed231a1/notes2/slr0.html
residue=fit_y-y';
SS_resid=sum((residue).^2);

%standar error of estimate
SE_yx=sqrt(SS_resid/(length(y)-2));

%squared correlation coefficient x variable explains 
%sum_XX=(sum((x(2:end,:)-repmat(mean(x(2:end,:),2),1,length(y))).^2,2)) %here not include intercepte
s_XX=(x(2:end,:)-repmat(mean(x(2:end,:),2),1,length(y)));
sum_XX=sum(s_XX.^2,2);
sum_YY=sum((y-mean(y)).^2);
sum_XY=((x(2:end,:)-repmat(mean(x(2:end,:),2),1,length(y)))*(y-mean(y))') ;%here not include intercepte 
r_xy=sum_XY./sqrt(sum_XX*sum_YY);
r_squre=r_xy.^2;
F2=r_xy.^2./(1-r_xy.^2)*(length(y)-2);

%Test of regression coefficient
%Standard error of regression coefficient
SE_b=SE_yx./sqrt((sum_XX));
t=fit_coefficient(2:end)./SE_b;
df=length(y)-2;
pt=2*(1-tcdf2(abs(t),df));
     
%Test of regression model,here we need remove the first constant intercepte
%term
%in general regression
N=length(y);k=1;
SS_reg=(sum_XY).^2./sum_XX;
SS_res=sum_YY-SS_reg;
F0=SS_reg/k./(SS_res/(N-k-1));

%Test of regression model
%In simple regression
t_sq=(fit_coefficient(2:end).^2./SE_b.^2);
F=t_sq;
df1=1;df2=length(y)-2;
P=1-fcdf2(F0,df1,df2);

if abs(F2-F0)<1e-10 
    STATS.P=P;    %p value to regressin model fit
    STATS.F=F0;   %F statistic to regression model
    STATS.T=t;    %T value to regression coefficient BX
    STATS.PT=pt;    %P value to regression coefficient
    STATS.B=fit_coefficient;  %B is regression coefficient which includes model intercepte as well
    STATS.R2=r_squre;    %r square statistics to regresson model
    STATS.res=residue;  %fitted residues
else
    disp('Error in model I stop!')
    F,F0,F2
    return;
end



%This function is for generate motif dictionary
motif_len=8;    %motif length from 1 to 8
strings=['a','c','g','t'];
loop=1;
for i=1:motif_len
    tp_motif=[];
    for j=1:i   %loop in motif length
        for k=1:4   %loop in a,c,g,t
            tp_motif(loop)=strings(k);
        end
        
            

function psam=consensus2matrix(str)
%Transform consensus motif to PSAM weigt matirx format
chars = {'a', 'c', 'g', 't','r', 'y', 'w', 's','m', 'k','h','b','v','d','n'};
str_p=	[ 1,   1,   1 ,  1, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,1/3,1/3, 1/3,1/3,1/4];
str_idx={[1],[2],[3],[4], ...
	[1,3],[2,4],[1,4],[2,3],[1,2],[3,4], ...
	[1,2,4],[2,3,4],[1,2,3],[1,3,4],[1,2,3,4]};
w=zeros(4,length(str));

for i=1:length(str)
	str_pos=strmatch(lower(str(i)),chars)  ;
	w(str_idx{str_pos},i)=str_p(str_pos);
end

%new_w=(w*length(str)+1)/(length(str)+4);	%put one seudo count in Probability
%new_w=(w+0.25)/max(max(w+0.25)); 
%psam=new_w;
%psam=new_w./repmat(max(new_w,[],1),4,1); 	%now transform probability to PSAM format for MatrixReduce	
%psam=new_w/max(max(new_w));

%Relative frequence based on RSA tools and prior Pi is taken from paper from Li Wen-Hsiung 2006  Bioinformatics: a=0.31, c=0.19, g=0.19, t=0.31
new_w=w./repmat(sum(w),4,1);
%Pi=repmat( [0.31;0.19;0.19;0.31],1,size(new_w,2));	%this is only for yeast
Pi=repmat( [0.25;0.25;0.25;0.25],1,size(new_w,2));
rel_w=new_w+Pi./(repmat(sum(w),4,1)+1);

%transform relative frequence to the weight based on RSA tools
%weights=log(rel_w./Pi);

%transform relative frequence to probability 
psam=rel_w./repmat(sum(rel_w),4,1);
%psam=rel_w;

%transform relative frequence to PSAM
%psam= rel_w./repmat(max(rel_w),4,1);


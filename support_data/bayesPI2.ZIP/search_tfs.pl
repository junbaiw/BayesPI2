#!/usr/bin/perl -w
use lib "/titan_home/u1/junbaiw/local/Perl_Modules";
use strict;

use Bio::SeqIO;
use Getopt::Long; 
use Cwd;
#This program is used to search available TFs (i.e. yeast cellcycle PSAM) on predicted motifs (i.e. mlp out data) 

#read parameters
use vars map {"\$opt_$_"} qw(tfFile outFile);
GetOptions qw(tfFile=s outFile=s);
print "must specify -tfFile of TF names to test." and die unless defined $opt_tfFile;
print "must specify -outFile of out file names to test." and die unless defined $opt_outFile;

#read TFs
open TF, "<$opt_tfFile" or die "could not open : $!";
my %tfs=();
while (<TF>) {
	chomp;
	my $temp="\L$_";
	$temp=~s/\s//g;
	$tfs{$temp}=$temp;
}
close TF;

#read out file names
open OUT, "<$opt_outFile" or die "could not open : $!";
my %files=();
my $loop=0;
while (<OUT>) {
        chomp;
        my $temp="\L$_";
 	$temp=~s/\s//g;
	my $temp2=join "\/",('out',$temp,'in','mRNA_cellCycle','cellCycle_alpha');
        $files{$loop}=$temp2;
	$loop++;	
	#print "$temp $temp2\n";
}
close OUT;

#search TFs within each file folder

for my $ii (0..$loop-1) {	#loop in each file
	my $temp_file=$files{$ii};
	my $temp_tf=();
	my %record_tfs=();
	print "$temp_file\n";	
	foreach (keys %tfs) {	#loop in each TF
		$temp_tf=$_;
		my $doit= join "", ("./compare_psam_p_mRNA.pl -databaseFile SGD_yeast_p -tfName ",$temp_tf,' -predictedFile ',$temp_file, ">temp_out");
		#print "$doit\n";
		if (system($doit)==0) {
			my $temp_out="temp_out";
			open TEMP, "<$temp_out"  or die "could not open $temp_out $!";
			while (<TEMP>) {
				chomp;
				my $temp_line=$_;
				$temp_line=~s/\s//g;
				if (length($temp_line) gt 1) {
				#	print "-> $_\n";
					my @line=split /\t/, $_;
					my $nums=@line;
					if ($line[$nums-2] >= 0.85){
						print "$_\n";
					}
				}
			}
			close TEMP;
		} else {
			print "system $doit failed: ";
		}
	}
}

function [g, gdata, gprior] = wang_mlpgrad_lasso(net, x, t,nucleosome_t)
global isnucleosome
%MLPGRAD Evaluate gradient of error function for 2-layer network.
%
%	Description
%	G = MLPGRAD(NET, X, T) takes a network data structure NET  together
%	with a matrix X of input vectors and a matrix T of target vectors,
%	and evaluates the gradient G of the error function with respect to
%	the network weights. The error funcion corresponds to the choice of
%	output unit activation function. Each row of X corresponds to one
%	input vector and each row of T corresponds to one target vector.
%
%	[G, GDATA, GPRIOR] = MLPGRAD(NET, X, T) also returns separately  the
%	data and prior contributions to the gradient. In the case of multiple
%	groups in the prior, GPRIOR is a matrix with a row for each group and
%	a column for each weight parameter.
%
%	See also
%	MLP, MLPPAK, MLPUNPAK, MLPFWD, MLPERR, MLPBKP
%
%	Copyright (c) Ian T Nabney (1996-2001)
%This is a modification of original mlpgrad.m by Junbai Wang May 2007
%

% Check arguments for consistency
errstring = consist(net, 'mlp', x, t);
if ~isempty(errstring);
  error(errstring);
end

if isnucleosome
    [y, z] = wang_mlpfwdC_nucleosome(net, x',nucleosome_t);
%[y, z] = wang_mlpfwd(net, x);
else
    [y, z] = wang_mlpfwdC(net, x');
end

delout = y - t;
if isnucleosome
    gdata = wang_mlpbkpC_nucleosome(net, x',nucleosome_t, z, delout);
else
    gdata = wang_mlpbkpC(net, x', z, delout);
%gdata = wang_mlpbkp(net, x, z, delout);
end

[g, gdata, gprior] = wang_gbayes_lasso(net, gdata);

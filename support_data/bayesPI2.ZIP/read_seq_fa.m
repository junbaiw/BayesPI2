function [gene_id4,gene_seq4,gene_seq_idx4]=read_seq_fa(fileseq)
%read sequence in fast file format 
%I have to remove genes with empty sequences or all repeat masked sequences! aug 2009
%
chars = {'a', 'c', 'g', 't','n'};
[fid,msg]=fopen(fileseq,'rt');
if fid<0
    error('Can not open file');
end 
idx=1; 
idx2=1;
gene_seq_idx=[];
ishead=0;
tstring=[];
max_seq_len=1000;	%the default is 3000 but for multiple species it is 150 : This parameter may need change
max_genes=1000;
gene_seq=cell(1,max_genes); %here the gene number change be changed if it is needed!
gene_id=cell(1,max_genes);
loop=1;
gene_seq_idx=zeros(max_genes,max_seq_len);
while 1 
        tline=fgets(fid);
        if ~ischar(tline) 
                break; 
        else
		tline=lower(deblank(tline));
	end 
        is_name=strmatch('>',tline); 
        if ~isempty(is_name) & is_name==1 
                 gene_id{idx}=strrep(deblank(tline(2:end)),char(10),''); 
                idx=idx+1; 
		ishead=1;
        else 
		if ishead==1 & idx >2 %start new id and push all old sequence to the cell
                	gene_idx=[];
                	gene_seq{idx2}=tstring; 
                	gene_idx=zeros(1,max_seq_len); 
                	for i=1:5 
                        	idx_s=[];
                        	idx_s=findstr(chars{i},lower(tstring));
                        	gene_idx(idx_s)=i;
                	end
			%gene_seq_idx=[gene_seq_idx;gene_idx];
             gene_seq_idx(loop,:)=gene_idx;
             loop=loop+1;
			idx2=idx2+1;
			tstring=[];
			tstring=tline;
			ishead=0;
		else
		   	tstring=[tstring,tline];
			ishead=0;
		end
        end
	
end
fclose(fid);

%add last line
gene_idx=[];
gene_seq{idx2}=tstring;
gene_idx=zeros(1,max_seq_len);
for i=1:5
    idx_s=[];
    idx_s=findstr(chars{i},lower(tstring));
    gene_idx(idx_s)=i;
end
%gene_seq_idx=[gene_seq_idx;gene_idx];
gene_seq_idx(loop,:)=gene_idx;
loop=loop+1;
idx2=idx2+1;
tstring=[];
ishead=0;

gene_id2=gene_id(1:idx-1);
gene_seq2=gene_seq(1:idx2-1);
gene_seq_idx2=gene_seq_idx(1:loop-1,:);

%check sequence lengths and remove too short sequences such as length<20, added aug 2009
min_seq_length=30; %this parameter can be adjusted.
gene_seq3=cell(size(gene_seq2)); %here the gene number change be changed if it is needed!
gene_id3=cell(size(gene_id2));
gene_seq_idx3=zeros(size(gene_seq_idx2));

loop=1;
short_seq=0;
for i=1:length(gene_id2)
	temp=length(deblank(gene_seq2{i}));
	temp2=sum(gene_seq_idx2(i,:)==0);	%check if the sequences are all masked by repeat.
	if (temp>min_seq_length & temp2<length(gene_seq_idx2(i,:)) )
		%gene_id3(loop)=gene_id2(i);
		%gene_seq3(loop)=gene_seq2(i);
		%gene_seq_idx3(loop,:)=gene_seq_idx2(i,:);
		%here we take a simple approach by removing repeat masked sequnece from input sequence!
		temp_seq_idx1=[];temp_seq_idx2=[];temp_seq_idx3=[];
		temp_seq=[];
		temp_seq_idx1=find(gene_seq_idx2(i,:)~=5 & gene_seq_idx2(i,:)~=0);	%remove repeat and empty cell from sequence
		temp_seq=gene_seq2{i};
		temp_seq_idx2=findstr(lower(temp_seq),'n');
		temp_seq_idx3=setdiff(1:length(temp_seq),temp_seq_idx2);
		if length(temp_seq_idx3)>min_seq_length
			gene_id3(loop)=gene_id2(i);
			gene_seq3{loop}=temp_seq(temp_seq_idx3);
			temp_idx=zeros(size(gene_seq_idx2(i,:)));
			temp_idx(1:length(temp_seq_idx1))=gene_seq_idx2(i,temp_seq_idx1);
			gene_seq_idx3(loop,:)=temp_idx;
			loop=loop+1;
		end
	else
		%temp,gene_seq2{i}
		short_seq=short_seq+1;
	end
end

max_col= max(sum((gene_seq_idx2>0),2));
gene_id4=gene_id3(1:loop-1);
gene_seq4=gene_seq3(1:loop-1);
gene_seq_idx4=gene_seq_idx3(1:loop-1,1:max_col);
disp(['Removed ',num2str(short_seq),' short sequences (',num2str(min_seq_length),')'] );
%for saving memory
clear gene_id gene_seq

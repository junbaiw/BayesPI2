function [record_net,x_binary,new_t]=bayes_motif_finding_loop_P(fileexp,filep,fileseq,L,max_loop,seed,nhidden,out_fold,selection_percentage,pcutoff)
%fileexp= expression file name
%fileseq= sequences file name
%L = motif length
%max_loop= maximum number of motifs
format long e

t11=clock;
%Input data parameters
randn('state',0); %ceil(abs(randn)*100));
rand('state',0);  %ceil(abs(randn)*100));
%the random initial values to the weights will effect the final estimations
%

%Read expression data
[t1,t_cases1,t_vars1]=tblread(fileexp,'\t');
% sort(t1(find(~isnan(t1))))

%Read p values
[p1,p_cases1,p_vars1]=tblread(filep,'\t');


if min(t1)<0
	t1=2.^t1;	%transform to real ratios 
end

%sort(t1(find(~isnan(t1))))
%pause
%Remove outlier
out_alpha=pcutoff/size(find(~isnan(t1)),1) %0.000001 %0.001; %for some data we may need p=0.000001 for example bas1 and fhl1
out_rep=1;
[b,idx,outliers] = deleteoutliers(log2(t1),out_alpha,out_rep);
t1=real(2.^b);
disp(['Grubbs test to remove ', num2str(size(find(~isnan(outliers)),1)),' outliers ...' ]);
idx_nan=find(~isnan(t1));
t0=t1(idx_nan,:);
t_cases=t_cases1;
t_vars0=t_vars1(idx_nan,:);

%merge P and ratios
[cc,cia,cib]=intersect(lower(deblank(t_vars0)),lower(deblank(p_vars1)),'rows');
new_gene_names=cc;
new_ratios=t0(cia,:);
new_p=p1(cib,:);

%select subset datasets according to P values=selection_percentage
%[st,sti]=sort(t0,'descend');
[st,sti]=sort(new_p,'ascend');

%st_vars=t_vars0(sti,:);
st_vars=new_gene_names(sti,:);
st_ratios=new_ratios(sti,:);
[rows, cols]=size(st_ratios);
top_idx=find(st<selection_percentage(1));		%ceil(rows*selection_percentage);
dow_idx=find(st>selection_percentage(2));	 %ceil(rows-top_idx);
new_idx_gene=[top_idx;dow_idx];
t=[]; t_vars=[];
t=st_ratios(new_idx_gene);
t_vars=st_vars(new_idx_gene,:);

%read sequence data
[gene_id,gene_seq,gene_seq_idx]=read_seq_fa(fileseq);
%len_gene=length(gene_id);
%idx_gene_selection=1:len_gene;	%randperm(len_gene);
%if isempty(selection_percentage)
%	selection_percentage=1;
%end
%new_idx_gene=idx_gene_selection(1:ceil(len_gene*selection_percentage));

%gene_id=gene_id(new_idx_gene);
%gene_seq=gene_seq(new_idx_gene);
%gene_seq_idx=gene_seq_idx(new_idx_gene,:);
disp(['Select p<', num2str(selection_percentage(1)), ' and p>', num2str(selection_percentage(2)),' total ', num2str(length(new_idx_gene)), ' genes in input data !']);


%take an intersection between sequence and expression data
if exist('intersect')>0
	[cc,ai,bi]=intersect(strvcat(lower(deblank(gene_id))),strvcat(lower(deblank(t_vars))),'rows');
else
	cc=[];
	loop=1;
	for i=1:length(gene_id)
        	tp=strmatch(lower(deblank(gene_id{i})),lower(deblank(t_vars)),'exact');
        	if ~isempty(tp)
                	ai(loop)=i;
               	bi(loop)=tp(1);
                	cc{loop}=lower(deblank(gene_id{i}));
                	loop=loop+1;
 	      	end
	end
end
new_id=cc;
%if length(find(t(bi,:)<0))==0
%	disp('Log2 transform of input data')
%	new_t= log2(t(bi,:));   %log2 transform of expression data if it is real ratios
%else
	new_t=t(bi,:);
	disp('No log2 transform of input data')
%end

new_seq=gene_seq_idx(ai,:);
new_seq_str=gene_seq(ai);
%%%%
%%%%%
ndata = size(new_t,1);
max_col=max(find(sum(new_seq,1)));
x=new_seq(:,1:max_col); %gene_seq_idx;
target=new_t; 
disp(['Read: gene ',num2str(size(t,1)),'; sequence length ',num2str(max_col)])

%motif length
%for saving memory
clear new_seq cc bi ai;

%this part can be removed if donot need compute the motif counts
%[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=compute_motif_counts(new_seq_str,L,max_col);
%motif_counts
%motif_counts=4096 %6m
disp('Finishing read data and motif counts ....')

% Set up network parameters.
med_N=median(sum(x>0,2));    %
N=size(x,2);  %sequence length
%L=8;    %motif length plus 2 flank region in each site
nin = N*4;			% Number of sequence base times 4.
if isempty(nhidden)
	nhidden=1;			% Number of hidden units.
end
nout = 1;			% Number of outputs.
aw1 = 0.01; %repmat( 0.01,1,L);         %*ones(1, nin);	% First-layer ARD hyperparameters.
ab1 = 0.01;			% Hyperparameter for hidden unit biases.
aw2 = 0.01;			% Hyperparameter for second-layer weights.
ab2 = 0.01;			% Hyperparameter for output unit biases.
coupling =[ ];		% add 2 Hyperparameter for coupling weight in W1
beta =50;			% Coefficient of data error.

%transform sequence x to binary representation of sequence For example,
%A=[ACGT -> 1000],C=[ACGT -> 0100],G=[ACGT -> 0010],T=[ACGT -> 0001],
%transform x to sequence index,
x_binary=sequence2binary(x);
each_seq_len=sum(x_binary,2);

% Create and initialize network.
%prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L);
%seed='cgcgaaaa';	%seed motif
%seed=[];
%net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L,each_seq_len,med_N,seed);
%disp('Initial values')
%reshape(net.w1(:,1),4,L),net.b1,net.w2,net.b2

% Set up vector of options for the optimiser.
nouter = 5;			% Number of outer loops
ninner = 10;		        % Number of inner loops
options = zeros(1,18);		% Default options vector.
options(1) = 0;			% This provides display of error values.
options(2) = 1.0e-7;	% This ensures that convergence must occur
options(3) = 1.0e-7;
options(14) = 500;		% Number of training cycles in inner loop. 
%options(9)=1; 	%check gradient
%net.motif_counts=motif_counts;

%start to do motif search
record_net=[];
all_loop=1;
disp('Start to compute PWM ....')
%each_seq_len=net.each_seq_len;

%loop in motif L
for ii=1:length(L);
	%Initial weights
	L(ii)
	[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=compute_motif_counts(new_seq_str,L(ii),max_col);
	motif_counts
	net.motif_counts=motif_counts;
	loop=1;
	prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii));
	net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed);
	target=new_t;
	disp('Initial values')
	reshape(net.w1(:,1),4,L(ii)),net.b1,net.w2,net.b2
	while loop<=max_loop
		for k=1:nouter
			%for each loop , randomly select 80% of origianl dataset for training,
			%[rows,cols]=size(t);
			%idx_rows=randperm(rows);
			%r_idx=idx_rows(1:ceil(rows*0.8));		
			%t2=t(r_idx,:);
			%x_binary2=x_binary(r_idx,:);
			%net.each_seq_len=each_seq_len(r_idx);
			%		if (~isempty(net.seed) & k==1)
			%			[net, soptions, svarargout] = wang_netopt(net, options, x_binary2,(t2),'scgC_fixW1');
			%			disp('with seed matrix ...');
			%   		else	
			%if k==1
			%	disp('Initial fitting fix w2')
			%	[net, soptions, svarargout] = wang_netopt(net, options, x_binary,(t),'scgC_fixW2');
			%else
				disp('estimate w2 ...')
				[net, soptions, svarargout] = wang_netopt(net, options, x_binary,(target),'scgC');
			%end
		 	disp('no seed matrix ...');
			%		end
			 disp('Do evidence inference ...');
			[net, gamma] = wang_evidence(net, x_binary, (target), ninner);     %some error in
    			% the evidence computations??
    			reshape(net.w1(:,1),4,L(ii)), net.alpha, net.beta
    			[k,soptions(10)]
    			%if soptions(10)<options(14)  %stop to search if it is converged
    			% 		break;
    			%end
		end
		net.motif_counts=motif_counts; 
		net.each_seq_len=each_seq_len;
        	[fy,fz,fa]=wang_mlpfwdC(net,x_binary');
		old_target=target;
		target=fy-(target);
		%test whether should we stopi
		old_var=cov(old_target)
		fit_var=cov(target)
		total_devs=abs( size(find(~isnan(target)),1)*(log(det(old_var))-log(det(fit_var))) )
		df=prod(size(net.w1))+prod(size(net.b1))+prod(size(net.w2))+prod(size(net.b2))-1
		total_p=Chisq(total_devs,df)	   %%bonferroni correction ??
		%1- cdf('chi2',total_devs,df)
		
                %test sum square of errors
	 	%ssr=sum((fy-mean(old_target)).^2);
 		%sse=sum((fy-old_target).^2);
                %sst=sum((old_target-mean(old_target)).^2);
                %F=ssr/sse
                %r2=ssr/sst
		%1-sse/sst

		%adjusted sum squared error
                mse=sum((fy-old_target).^2)/(size(find(~isnan(target)),1)-2); 
                mst=sum((old_target-mean(old_target)).^2)/(size(find(~isnan(target)),1)-1);
                msr=sum((fy-mean(old_target)).^2)/(2-1);
                F=msr/mse	%F values
                r2=1-mse/mst   	%Coefficient_of_determination

                %convert r2 to t values
                %r0=(1.63+0.58*df)/sqrt(size(target,1));
                %sigma=0.66/sqrt(size(target,1));
                %t=abs(sqrt(r2)-r0)/sigma
        	%comput p of t values
                %ppt=1/sqrt(df)/beta(1/2,17)*(1+t^2/df)^((-df-1)/2)
      		
		[rr,rrp]=corrcoef(fy,old_target)  
                tt=rr(1,2)*sqrt((size(find(~isnan(target)),1)-2)/(1-rr(1,2)^2))
                pt=2*(1-tcdf(tt,motif_counts-1))  %bonferroni correction ??
 
                if ((total_p>0.001/df | pt > 0.001/motif_counts )& loop>6 )
			disp('No information available in the data, I runed at least three times then stop!');
			break;
		else
                        %make new predictions
                         net.F=F;
                         net.r2=r2; net.total_p=total_p;net.motif_p=pt; net.motif_t=tt;
                         record_net{all_loop}=net;
                         loop=loop+1;
                         all_loop=all_loop+1;
                        
                         % Create and initialize network.
                         prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii));
                         net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed);
                	 motif_counts=motif_counts-1;
		         net.motif_counts=motif_counts;
                         net.each_seq_len=sum(x_binary,2);
                end
		loop	
		%pause

	end
end

out_string=['save ', out_fold,'/',fileexp,'_mlpout_motifL',num2str(min(L)),'_',num2str(max(L)),'.mat']
eval(out_string);
etime(clock,t11)

% Train using scaled conjugate gradients, re-estimating alpha and beta.


function hdv = wang_mlphdotv_Ew_cauchy(net, x, t, v)
%MLPHDOTV Evaluate the product of the data Hessian with a vector. 
%
%	Description
%
%	HDV = MLPHDOTV(NET, X, T, V) takes an MLP network data structure NET,
%	together with the matrix X of input vectors, the matrix T of target
%	vectors and an arbitrary row vector V whose length equals the number
%	of parameters in the network, and returns the product of the data-
%	dependent contribution to the Hessian matrix with V. The
%	implementation is based on the R-propagation algorithm of
%	Pearlmutter.
%
%	See also
%	MLP, MLPHESS, HESSCHEK
%
%	Copyright (c) Ian T Nabney (1996-2001)
%This is a modificaiton of original mlphdotv.m , Modified by Junbai Wang May 2007

% Check arguments for consistency
errstring = consist(net, 'mlp', x, t);
if ~isempty(errstring);
  error(errstring);
end

ndata = size(x, 1);
vnet = wang_mlpunpak(net, v);	% 		Unpack the v vector.
w=wang_mlppak(net);
zprime=zeros(ndata,net.nhidden);
zpprime=zeros(ndata,net.nhidden);
ra1=zeros(ndata,net.nhidden);
rz=zeros(ndata,net.nhidden);
ra2=zeros(ndata, 1) ; %net.nhidden);
hw1=zeros(net.motif_L*4,net.nhidden);
hw2=zeros(net.nhidden,1);

% Prevent overflow and underflow: use same bounds as mlperr
% Ensure that log(1-y) is computable: need exp(a) > eps
maxcut = log(1/realmin-1); %-log(eps);
% Ensure that log(y) is computable
mincut = log(eps); %-log(1/realmin - 1);  

%Do Forward
%a2=log(1+H^2)
H=net.index*net.alpha.*w';
%a1=w

%Do Backward
d_a2=1./(net.index*net.alpha);
d_H=d_a2.*(2.*H./(1+H.^2));
d_a1=2.*H./(1+H.^2);
d_w=d_a1;

%Do R-forward
r_a1=wang_mlppak(vnet)';
r_H=net.index*net.alpha.*r_a1;
%r_a2=sum(2.*H./(1+H.^2).*r_H);

%Do R-backward
r_dw=-2.*(H.^2-1)./(H.^2+1).^2.*r_H;
hdv=r_dw';

%to avoid zeros
hdv=hdv+eps.*(hdv<eps);


function hdv = wang_mlphdotv(net, x, t, v)
%MLPHDOTV Evaluate the product of the data Hessian with a vector. 
%
%	Description
%
%	HDV = MLPHDOTV(NET, X, T, V) takes an MLP network data structure NET,
%	together with the matrix X of input vectors, the matrix T of target
%	vectors and an arbitrary row vector V whose length equals the number
%	of parameters in the network, and returns the product of the data-
%	dependent contribution to the Hessian matrix with V. The
%	implementation is based on the R-propagation algorithm of
%	Pearlmutter.
%
%	See also
%	MLP, MLPHESS, HESSCHEK
%
%	Copyright (c) Ian T Nabney (1996-2001)
%This is a modificaiton of original mlphdotv.m , Modified by Junbai Wang May 2007

% Check arguments for consistency
errstring = consist(net, 'mlp', x, t);
if ~isempty(errstring);
  error(errstring);
end

ndata = size(x, 1);

%[y, z] = wang_mlpfwd(net, x);		% Standard forward propagation.
[y, z] = wang_mlpfwdC(net, x');
vnet = wang_mlpunpak(net, v);	% 		Unpack the v vector.
% Do the R-forward propagation.
%ra1 = x*vnet.w1 + ones(ndata, 1)*vnet.b1;
%rz = zprime.*ra1;
%ra2 = rz*net.w2 + z*vnet.w2 + ones(ndata, 1)*vnet.b2;

% Evaluate delta for the output units.
delout =( y - t);

%added wang
deltas=delout*net.w2';
deltas_v=delout*vnet.w2';

zprime=zeros(ndata,net.nhidden);
zpprime=zeros(ndata,net.nhidden);
ra1=zeros(ndata,net.nhidden);
rz=zeros(ndata,net.nhidden);
ra2=zeros(ndata, 1) ; %net.nhidden);
delhid=zeros(ndata,net.nhidden);
rdelhid=zeros(ndata,net.nhidden);
%hw1=zeros(ndata,net.motif_L*4);
hw1=zeros(net.motif_L*4,net.nhidden);
%hw2=zeros(ndata,net.nhidden);
hw2=zeros(net.nhidden,1);

% Prevent overflow and underflow: use same bounds as mlperr
% Ensure that log(1-y) is computable: need exp(a) > eps
maxcut = log(1/realmin-1); %-log(eps);
% Ensure that log(y) is computable
mincut = log(eps); %-log(1/realmin - 1);  

for i=1:net.sequence_L-net.motif_L+1
    %loops in sequence motif windows
    tp_x=x(:,((i-1)*4+1):(i+net.motif_L-1)*4)  ; 
    iszeros= (sum(tp_x,2)>net.motif_L-1) ;    %remove sequence idx is zero
    iszeros=repmat(iszeros,1,net.nhidden);

    aa=tp_x*net.w1-ones(ndata,1)*net.b1; %test
    aa(find(aa<mincut))=mincut;
    aa(find(aa>maxcut))=maxcut;

    if isfield(net,'motif_p')
    	%find oligo prob
    	[str_p]=net.motif_p(:,i);   %index2char(tp_x,net.motif_L,net.oligos,net.oligos_p);
    	tz=exp(aa);
    	tz_prime=-str_p.*tz./(1+tz).^2.*iszeros;
    	tz_pprime=str_p.*tz.*(tz-1)./(1+tz).^3.*iszeros;
 	tz_1=str_p./(1+tz).*iszeros;
    else
	tz=exp(aa);
        tz_prime=(-tz./(1+tz).^2).*iszeros; 
        tz_pprime=(tz.*(tz-1)./(1+tz).^3).*iszeros; 
	tz_1=(1./(1+tz)).*iszeros; 
    end

    % Do the R-forward propagation.
    t_ra1=(tp_x*vnet.w1-ones(ndata,1)*vnet.b1).*iszeros; 
    ra1=ra1+t_ra1; %.*iszeros; 
    t_rz=tz_prime.*t_ra1.*iszeros;
    rz=rz+t_rz; %.*iszeros; 
    t_ra2=(t_rz*net.w2+tz_1*vnet.w2+ones(ndata,1)*vnet.b2).*iszeros(:,1); 
    ra2=ra2+t_ra2; 
%	[size(t_ra1),size(t_rz),size(ra2)]

    % Do the standard backpropagation.
    t_delhid=tz_prime.*deltas;
    delhid=delhid+t_delhid.*iszeros; 
%	[size(t_delhid),size(delhid)]

    % Now do the R-backpropagation.
%	[size(t_ra2),size(net.w2')]
    ry_time_w=t_ra2*net.w2'  ;  %here we assume linear output ry=ra2!
%	[size(ry_time_w),size(t_ra2),size(net.w2')]
    tz_rdelhid=(tz_pprime.*t_ra1.*deltas+ tz_prime.*deltas_v+tz_prime.*ry_time_w).*iszeros;
    rdelhid=rdelhid+ tz_rdelhid; 
    hw1=hw1+tp_x'*(tz_rdelhid); 	
    hw2=hw2+(tz_1'*t_ra2+t_rz'*delout); 	%added
%	[size(tz_1'*t_ra2),size(tz_1),size(t_ra2)]
end

switch net.outfn

case 'linear'      % Linear outputs
   ry = ra2;
case 'logistic'    % Logistic outputs
   ry = y.*(1 - y).*ra2;
case 'softmax'     % Softmax outputs
   nout = size(t, 2);
   ry = y.*ra2 - y.*(sum(y.*ra2, 2)*ones(1, nout));
otherwise
   error(['Unknown activation function ', net.outfn]);  
end

% Finally, evaluate the components of hdv and then merge into long vector.
%added wang
%hw1 = x'*rdelhid; %??
%hw1=sum(hw1,1);
%end added
hb1 = sum(-rdelhid, 1); %test
%hw2 = z'*ry + rz'*delout;
%hw2=sum(hw2,1);
hb2 = sum(ry, 1);
hdv = [hw1(:)', hb1, hw2(:)', hb2];

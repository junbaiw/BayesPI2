function [record_net,x_binary,new_t]=BayesPI_loop_cauchy(fileexp,fileseq,L,max_loop,seed,nhidden,...
    out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat,alphaClass)
global isnucleosome 
%global alphaClass
%This is for Cauchy approximation loops
%fileexp= expression file name
%fileseq= sequences file name
%L = motif length
%max_loop= maximum number of motifs
%alphaClass=1;   %Here we set hyperparameter alpha have 3 groups as David Mackay's paper in 1994
format long e
if  nargin==11
	isreverse=0;	%this experiment issnot reversed defalut settinga
	disp('This is not a reversed experiment!')
end
t11=clock;
%Input data and parameters
randn('state',0); %ceil(abs(randn)*100));
rand('state',0);  %ceil(abs(randn)*100));
%the random initial values to the weights will effect the final estimations
[x,new_seq,new_seq_str,max_col,mean_new_nuc_t,new_t]=BayesPI_readData(fileexp,fileseq,L,max_loop,seed,nhidden,...
    out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat);

%compute the motif counts
%[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=BayesPI_motifCounts(new_seq_str,L,max_col);
%motif_counts
%motif_counts=4096 %6m
disp('Finishing read data ....')

%find motif counts for each motif and each gene
%useseed=0;
%if useseed
%    record_count=zeros(size(new_seq_str,2),length(all_motifs));
%    for i=1:size(new_seq_str,2)
%        for j=1:length(all_motifs)
%            record_count(i,j)=length(findstr(new_seq_str{i},all_motifs{j}));
%        end
%    end
%    rr_motifs=zeros(size(all_motifs));
%    for i=1:length(all_motifs)
%        tr=corrcoef(record_count(:,i),new_t);
%        rr_motifs(i)=tr(1,2);
%    end
%    [max_m,max_i]=max(rr_motifs);
%    flanking_len=3 %flanking sequence in the two sides
%    seed=all_motifs{max_i};
%    if flanking_len>0
%        seed=[repmat('n',1,flanking_len),seed,repmat('n',1,flanking_len)]
%        L=L+flanking_len*2;
%    end
%    new_record_counts=record_count(:,[1:max_i-1,max_i+1:end]);   %remove seed motif from count table
%    new_all_motifs=all_motifs([1:max_i-1,max_i+1:end]);
%else
   seed=[]; 
%end
    
%set network parameters
[N,nin,nhidden,nout,t_aw1,ab1,aw2,ab2,beta,x_binary,each_seq_len,...
    nouter,ninner,options,record_net,all_loop,coupling,med_N,out_string]=BayesPI_setParameters(x,isrepeat,out_fold,fileexp,L,nhidden,alphaClass);

%loop in motif L
for ii=1:length(L);
    %compute the motif counts
    %[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=BayesPI_motifCounts(new_seq_str,L(ii),max_col);
    motif_counts=4^L(ii);
	disp('Finishing motif counts ....')

	%Initial weights
	L(ii)
    if length(L)>1 & alphaClass>4
        aw1=t_aw1{ii};
    else
        aw1=t_aw1;
    end
	motif_counts
	net.motif_counts=motif_counts;
	loop=1;
    if alphaClass==3
        prior = wang_mlpprior_3classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
        disp('There are 3 groups in hyperparameters -- Alpha! ')    
    elseif alphaClass==2
        prior = wang_mlpprior_2classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
        disp('There are 2 groups in hyperparameters -- Alpha! ') 
    elseif alphaClass==1
        prior = wang_mlpprior_1classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
        disp('There is only 1 groups in hyperparameters -- Alpha! ')
    elseif alphaClass==8
        
        prior = wang_mlpprior_LclassAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
        disp('There are L+3 groups in hyperparameters -- Alpha! ') 
    else
        prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
        disp('There are 4 groups in hyperparameters -- Alpha! ')
    end
    net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed,isnucleosome);
	target=som_normalize(new_t,'var');
    	target_nuc=(mean_new_nuc_t'); % ,'var');	%transform to Zscores
	disp('All input ratios are transformed to Z-scores now!')
	disp('Initial values')
    if isnucleosome	
	    reshape(net.w1(1:end-1*net.nhidden,1),4,L(ii)),
        [net.w1(end-1*net.nhidden+1:end),net.b1,net.w2,net.b2]
    else
        reshape(net.w1(1:end),4,L(ii)),[net.b1,net.w2,net.b2]
    end
    fy=[];
	while loop<=max_loop
		for k=1:nouter
				disp('estimate w2 ...')
                %net, net.alpha
                if isnucleosome
                    [net, soptions, svarargout] = wang_netopt_cauchy(net, options, x_binary,(target),target_nuc,'scgC_nucleosome_cauchy');
                else
                     [net, soptions, svarargout] = wang_netopt_cauchy(net, options, x_binary,(target),target_nuc,'scgC_cauchy');
                end
    			disp('Do evidence inference ...');
                %net.alpha
                %net, net.alpha, net.w1
			    [net, gamma] = wang_evidence_nucleosome_cauchy(net, x_binary, (target),target_nuc, ninner);     %some error in
           
    			% the evidence computations??
                if isnucleosome
    			    reshape(net.w1(1:end-1*net.nhidden,1),4,L(ii)),net.alpha, net.beta
                else
                    reshape(net.w1,4,L(ii)),net.alpha, net.beta
                end
    			[k,soptions(10)]
    			%if soptions(10)<options(14)  %stop to search if it is
    			%converged but the result may not so good therefore I
    			%removed it June 2009
    			% 		break;
    			%end
		end
		net.motif_counts=motif_counts; 
		net.each_seq_len=each_seq_len;
        
        %record all motif
        %tt_net=net;
        %tt_net.w2=1;    %remove w2,b2 but only keeps w1 and b1 in the model
        %tt_net.b2=0;
        %loop_net{loop}=tt_net;
        [tt_fy,tt_fz,tt_fa]=wang_mlpfwdC(net,x_binary'); %compute sequence scores
        %fy=[fy,tt_fy];
		old_target=target;
		%target=tt_fy-(target);
	
        temp_xx=[ones(size(tt_fz,1),1),tt_fz];      %add the interecpt
        temp_yy=target;
        %size(temp_xx),size(temp_yy),net
        [STATS]=simple_regression2(temp_xx',temp_yy',net.nwts)
       % [b,bint,r,rint,stats] = marray_regress2(temp_yy,temp_xx,0.05);
       % [r,STATS.res],
       % stats, b
        total_p=STATS.P;
        F2=STATS.F;
        r_squre=STATS.R2;
        tt=STATS.T;
        pt=1-(1-STATS.PT)^motif_counts;
        target=STATS.res;
        
        if     (( pt>0.0001 & loop>3 )| loop>max_loop )
                disp('No information available in the data, I runed at least three times then stop!');
			break;
		else
                        %make new predictions
                         net.F=F2;
                         net.r2=r_squre; net.total_p=total_p;net.motif_p=pt; net.motif_t=tt;
                     	 net.each_seq_len=[]	; %for saving memory
                         net.seqScore=tt_fz;
			             record_net{all_loop}=net;
                         loop=loop+1;
                         all_loop=all_loop+1;
			
			            record_net,fileexp,L,out_fold	
			            %export data
			            export2AffinityLogo(record_net,fileexp,L,out_fold);                       
		    		    eval(out_string);
 
                         % Create and initialize network.
                        if alphaClass==3
                            prior = wang_mlpprior_3classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
                        elseif alphaClass==2
                            prior = wang_mlpprior_2classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);   
                        elseif alphaClass==1
                            prior = wang_mlpprior_1classAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);   
                         elseif alphaClass==8
                            prior = wang_mlpprior_LclassAlpha(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
                            disp('There are L+3 groups in hyperparameters -- Alpha! ') 
                        else
                            prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
                        end    
                         net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed,isnucleosome);
                	     motif_counts=motif_counts-1;
		                 net.motif_counts=motif_counts;
                         %net.each_seq_len=each_seq_len;	%sum(x_binary,2); %added aug 2009                
        end
		loop	
		%pause
	end
end

out_string=['save ', out_fold,'/',fileexp,'_mlpout_motifL',num2str(min(L)),'_',num2str(max(L)),'.mat']
eval(out_string);
etime(clock,t11)

% Train using scaled conjugate gradients, re-estimating alpha and beta.


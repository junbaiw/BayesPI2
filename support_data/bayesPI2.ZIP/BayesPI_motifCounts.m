function [motif_counts,all_motifs,oligo_prob,total_bases,seq_length]=BayesPI_MotifCounts(gene_seq,L,seq_L)
%compute the number of motif counts
all_motifs=cell(1,100000000);

%compute total motif counts and oligo probability
temp_match=zeros(length(gene_seq),seq_L-L+1);
total_seq=[];
for i=1:length(gene_seq)
	total_seq=[total_seq,repmat(' ',1,L),gene_seq{i}];
end
loop=1;
for i=1:length(gene_seq)
       ts=gene_seq{i};
       seq_length(i)=length(ts);	
       for j=1:seq_length(i)-L+1
                tp_motif=ts(j:j+L-1);
                if length(deblank(tp_motif))==L
                    all_motifs{loop}=tp_motif; %cellstr(tp_motif);
                    %		temp_match(i,j)=length(findstr(tp_motif,total_seq));
                    loop=loop+1;
                end
       end
end
all_motifs=unique(all_motifs(1:loop-1));
motif_counts=length(all_motifs);

total_bases=sum(seq_length-L+1);
oligo_prob=[]; %temp_match./total_bases;


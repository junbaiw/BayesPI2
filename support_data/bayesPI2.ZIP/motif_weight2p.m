function [psam,rel_w]=motif_weight2p(motif_energy)
%here the prir probabilty is for yeast
%Relative frequence based on RSA tools and prior Pi is taken from paper from Li Wen-Hsiung 2006  Bioinformatics: a=0.31, c=0.19, g=0.19, t=0.31
w=motif_energy';
new_w=w./repmat(sum(w),4,1);
Pi=repmat( [0.25;0.25;0.25;0.25],1,size(new_w,2));
rel_w=new_w+Pi./(repmat(sum(w),4,1)+1);

%transform relative frequence to the weight based on RSA tools
%weights=log(rel_w./Pi);

%transform relative frequence to probability
psam=rel_w./repmat(sum(rel_w),4,1);
%psam=rel_w;



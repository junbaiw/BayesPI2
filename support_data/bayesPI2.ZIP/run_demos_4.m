%There are mainly four parts of parameters that you need to modify: 
%1) global alphaClass, 2) local parameters, 3) Out file
%options and 4) Other parameters 
%Usually, only the first two need be changed. Detailed explanation of each
%type of paramters please refer to below texts.
%
%The Norwegian Radium Hospital,
%Oslo, Norway
%Junbai Wang,
%May 2010
%
clear all
close all

%1) global alphaClass
%Input global parameters
%Here the input file "input_model_parameters" contains globle model parameters
%the first line is model name such as lasso, cauchy or gaussian
%the second line is the class number of alpha parameters which ranges from
%[1,2,3,4,5]
%
tt=clock;
[in_parameters]=textread('input_model_parameters','%s');
model=in_parameters{1}
alphaClass=str2double(in_parameters{2})


%2) Input local parameters
%Here you type input file names for chip-chip data and the corresponding
%sequences file (fasta format)
%L: is motif length and can use a vector such as [8:12] represents motif
%lengths from 8 to 12.
%max_loop: is the maximum number of detected motifs by one motif length
%seed: is a seed motif if you want to use it as initial search
%nhidden: is the number of hidden neurons in the neural networks
%
fileexp='demo_in/demo_swi4_1Kseq_cacgaaaa.txt'	%	demo_0.05Kseq_cacgaaaa.txt'	%demo_0.05Kseq_gctggt.txt'	%'demo_in/demo_0.05Kseq_gcctcgaagcga.txt'
fileseq='demo_in/demo_swi4_1Kseq_cacgaaaa.fa'	%	demo_0.05Kseq_cacgaaaa.fa'	%demo_0.05Kseq_gctggt.fa'	%'demo_in/demo_0.05Kseq_gcctcgaagcga.fa'
L=9 %[8:12]
max_loop=10
seed=[]; %'TGACTC'
nhidden=1

%3) out file options
%Here type your export file location such as out_fold, out_etime
%
if lower(model(1))=='g'
    o_fold='gaussian';
elseif lower(model(1))=='c'
    o_fold='cauchy';
elseif lower(model(1))=='l'
    o_fold='lasso';
else
    error(['Input model error! ', model]);
end
if alphaClass==1
    out_fold=['demo_out/',o_fold,'/demo_in/swi4_1k']
elseif alphaClass==2
    out_fold=['demo_out/',o_fold,'/demo_in2/swi4_1k']
elseif alphaClass==3
    out_fold=['demo_out/',o_fold,'/demo_in3/swi4_1k']
elseif alphaClass==4
    out_fold=['demo_out/',o_fold,'/demo_in4/swi4_1k']
elseif alphaClass>4
    out_fold=['demo_out/',o_fold,'/demo_in5/swi4_1k']
end
out_etime=[out_fold,'/',fileexp,'_L',num2str(max(L)),'_',num2str(min(L)),'_',num2str(alphaClass),'alpha_',model,'Etimes'];
fid=fopen(out_etime,'wt');
fprintf(fid, '%s\n',[model,'|',num2str(alphaClass),' alpha']);

%4) other parameters
%Here parameters are used in inference program
%percent_selection: use the top percentage of input chip-chip ratios which ranges from 0.1 to 1.
%pcutoff: is the cutoff value for P-value of outline detection
%fileann: 
%finenuc: file name of nucleunosme data if you want to use it.
%isreverse: 1 if the input chip is a reverse experiment, otherwise use 0.
%isrepeat: 1 if the input sequence is repeat masked, otherwise use 0.
%
percent_selection=1;
pcutoff=1e-20;
fileann=[];
filenuc=[];
isreverse=0;    %is reverse experiment
isrepeat=0;     %is DNA sequence be repeated masked

%Predict motifs
%[record_net,x_binary,target]=BayesPI_loop_cauchy(fileexp,fileseq,L,max_loop,...
%    seed,nhidden,out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat);
if lower(model(1))=='g'
        disp('Use Gaussian as a regularizer!')
        [record_net,x_binary,target]=BayesPI_loop(fileexp,fileseq,L,max_loop,...
    seed,nhidden,out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat,alphaClass);
elseif lower(model(1))=='c'
        disp('Use Cauchy as a regularizer!')
        [record_net,x_binary,target]=BayesPI_loop_cauchy(fileexp,fileseq,L,max_loop,...
        seed,nhidden,out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat,alphaClass);
elseif lower(model(1))=='l'
        disp('Use Lasso as a regularizer!')
        [record_net,x_binary,target]=BayesPI_loop_lasso(fileexp,fileseq,L,max_loop,...
        seed,nhidden,out_fold,percent_selection,pcutoff,fileann,filenuc,isreverse,isrepeat,alphaClass);
else
        error('Error input model!')
end

%Export matrix to AffinityLogo format for visualization
export2AffinityLogo(record_net,fileexp,L,out_fold);
et=etime(clock,tt);
fprintf(fid, '%s\n',['Elapsed_time','|',num2str(et/3600),' hours']);
fclose(fid);


%Predict motifs
%[record_net,x_binary,target]=bayes_motif_finding_loop(fileexp,fileseq,L,max_loop,seed,nhidden,out_fold,percent_selection,pcutoff,fileann);

%Export matrix to AffinityLogo format for visualization
%export2AffinityLogo(record_net,fileexp,L,out_fold);

break;




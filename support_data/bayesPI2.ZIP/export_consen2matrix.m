%file1='sgd_consensus_motifs.txt'
file1='human_consensus.txt'
[tfs,motifs]=textread(file1,'%s%s');
 for i=1:length(tfs) 
	tf_name=tfs{i} 
	tf_motif=motifs{i}
	tf_psam=consensus2matrix(tf_motif)
	%out_file=['SGD_yeast_p/SGD-',upper(tf_name),'_psam.txt']
	out_file=['human_p/human-',upper(tf_name),'_psam.txt']
	fid=fopen(out_file,'wt');
        fprintf(fid, '%s\n',[tf_motif,char(9),'#',char(9),tf_name]);
        fprintf(fid, '%s\n',['0.001     #       p-value']);
        fprintf(fid, '%s\n', ['8642     #       bonferroni' ]);
        fprintf(fid, '%s\n', ['0        #       derived from leading strand']);
        fprintf(fid, '%s\n', ['#        a       c       g       t']);
        for j=1:size(tf_psam,2)
           fprintf(fid, '%s\n', [tf_motif(j),char(9),num2str(tf_psam(1,j)),char(9),num2str(tf_psam(2,j)),char(9),num2str(tf_psam(3,j)),char(9),num2str(tf_psam(4,j))]);
        end
        fclose(fid);
end
	

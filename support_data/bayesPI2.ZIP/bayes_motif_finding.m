function [record_net,x_binary,new_t]=bayes_motif_finding(fileexp,fileseq,L,max_loop,seed,nhidden)
%fileexp= expression file name
%fileseq= sequences file name
%L = motif length
%max_loop= maximum number of motifs


t11=clock;
%Input data parameters
randn('state',0); %ceil(abs(randn)*100));
rand('state',0);  %ceil(abs(randn)*100));
%the random initial values to the weights will effect the final estimations
%

%Read expression data
[t1,t_cases1,t_vars1]=tblread2(fileexp,'\t');
idx_nan=find(~isnan(t1));
t=t1(idx_nan,:);
t_cases=t_cases1;
t_vars=t_vars1(idx_nan,:);

%read sequence data
[gene_id,gene_seq,gene_seq_idx]=read_seq_fa(fileseq);

%take an intersection between sequence and expression data
if exist('intersect')>0
	[cc,ai,bi]=intersect(strvcat(lower(deblank(gene_id))),strvcat(lower(deblank(t_vars))),'rows');
else
	cc=[];
	loop=1;
	for i=1:length(gene_id)
        	tp=strmatch(lower(deblank(gene_id{i})),lower(deblank(t_vars)),'exact');
        	if ~isempty(tp)
                	ai(loop)=i;
               	bi(loop)=tp(1);
                	cc{loop}=lower(deblank(gene_id{i}));
                	loop=loop+1;
 	      	end
	end
end
new_id=cc;
new_t= (t(bi,:));   %not log transform of expression data
new_seq=gene_seq_idx(ai,:);
new_seq_str=gene_seq(ai);
%%%%

%%%%%
ndata = size(new_t,1);
max_col=max(find(sum(new_seq,1)));
x=new_seq(:,1:max_col); %gene_seq_idx;
t=new_t; 
disp(['Read: gene ',num2str(size(t,1)),'; sequence length ',num2str(max_col)])

%motif length
%for saving memory
clear new_seq cc bi ai;

%this part can be removed if donot need compute the motif counts
%[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=compute_motif_counts(new_seq_str,L,max_col);
%motif_counts=4096 %6m
disp('Finishing read data and motif counts ....')

% Set up network parameters.
med_N=median(sum(x>0,2));    %
N=size(x,2);  %sequence length
%L=8;    %motif length plus 2 flank region in each site
nin = N*4;			% Number of sequence base times 4.
if isempty(nhidden)
	nhidden=1;			% Number of hidden units.
end
nout = 1;			% Number of outputs.
aw1 = 0.01; %repmat( 0.01,1,L);         %*ones(1, nin);	% First-layer ARD hyperparameters.
ab1 = 0.01;			% Hyperparameter for hidden unit biases.
aw2 = 0.01;			% Hyperparameter for second-layer weights.
ab2 = 0.01;			% Hyperparameter for output unit biases.
coupling =[ ];		% add 2 Hyperparameter for coupling weight in W1
beta =50;			% Coefficient of data error.

%transform sequence x to binary representation of sequence For example,
%A=[ACGT -> 1000],C=[ACGT -> 0100],G=[ACGT -> 0010],T=[ACGT -> 0001],
%transform x to sequence index,
x_binary=sequence2binary(x);
each_seq_len=sum(x_binary,2);

% Create and initialize network.
prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L);

%seed='cgcgaaaa';	%seed motif
%seed=[];
net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L,each_seq_len,med_N,seed);
disp('Initial values')
reshape(net.w1(:,1),4,L),net.b1,net.w2,net.b2

% Set up vector of options for the optimiser.
nouter = 10;			% Number of outer loops
ninner = 10;		        % Number of inner loops
options = zeros(1,18);		% Default options vector.
options(1) = 0;			% This provides display of error values.
options(2) = 1.0e-7;	% This ensures that convergence must occur
options(3) = 1.0e-7;
options(14) = 500;		% Number of training cycles in inner loop. 
%options(9)=1; 	%check gradient
%net.motif_counts=motif_counts;

%start to do motif search
record_net=[];
loop=1;
disp('Start to compute PWM ....')
each_seq_len=net.each_seq_len;
while loop<max_loop
	for k=1:nouter
	
		%for each loop , randomly select 80% of origianl dataset for training,
		[rows,cols]=size(t);
		idx_rows=randperm(rows);
		r_idx=idx_rows(1:ceil(rows*0.7));		
		t2=t(r_idx,:);
		x_binary2=x_binary(r_idx,:);
		net.each_seq_len=each_seq_len(r_idx);

%		if (~isempty(net.seed) & k==1)
%			[net, soptions, svarargout] = wang_netopt(net, options, x_binary2,(t2),'scgC_fixW1');
%			disp('with seed matrix ...');
%   		else	
			 [net, soptions, svarargout] = wang_netopt(net, options, x_binary2,(t2),'scgC');
			 disp('no seed matrix ...');
%		end
		[net, gamma] = wang_evidence(net, x_binary2, (t2), ninner);     %some error in
    		% the evidence computations??
    		reshape(net.w1(:,1),4,L)
    		[k,soptions(10)]
    	%	if soptions(10)<options(14)  %stop to search if it is converged
    	%    		break;
    	%	end
	end
	net.each_seq_len=each_seq_len;
        [fy,fz,fa]=wang_mlpfwdC(net,x_binary');
	record_net{loop}=net;
        loop=loop+1;  
	t=fy-(t);
        % Create and initialize network.
	prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L);
	net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L,each_seq_len,med_N,seed);
	%net.motif_counts=motif_counts-1;
	net.each_seq_len=sum(x_binary,2);
end

out_string=['save ', fileexp,'_mlpout_motifL',num2str(L),'.mat'];
eval(out_string);
etime(clock,t11)

% Train using scaled conjugate gradients, re-estimating alpha and beta.


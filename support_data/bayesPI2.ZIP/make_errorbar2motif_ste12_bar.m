clear all;close all
record_mean_energy=[];
record_std_energy=[];
%make Scre 
clear plot_energy
core_str3='tgaaacg'
file='multiple_yeast_out_for_support/matrices/Scer_Ste12_GSM124354-23652.txt_Extracted_mlpout_L8_5_1.mlp'
[motif_str, motif_energy]=read_bayesianReduce_mlp(file);
[psam,rel_w]=motif_weight2p(motif_energy);
IC=p2informationCount(psam)
core_energy=IC(:,2:8)
core_str=core_str3 %try to make the same core motif as the Sbay  

hold on
chars = ['acgt'];
for i=1:size(core_energy,2)
        idx=findstr(strvcat(chars), core_str(i) );
        plot_energy(i)=core_energy(idx,i);
end
ee3=plot(1:7,plot_energy,'gs-');

record_mean_energy(1,:)=plot_energy;
record_std_energy(1,:)=zeros(size(plot_energy));

%make Smik
clear motif_str1 motif_energy1 psam1 rel_w1 core_energy1
clear motif_str2 motif_energy2 psam2 rel_w2 core_energy2
clear motif_str3 motif_energy3 psam3 rel_w3 core_energy3

file1='multiple_yeast_out_for_support/matrices/Smik_Ste12_GSM123484-23638.txt_Extracted_mlpout_L8_5_1.mlp'
file2='multiple_yeast_out_for_support/matrices/Smik_Ste12_GSM123485-23640.txt_Extracted_mlpout_L7_5_1.mlp'
file3='multiple_yeast_out_for_support/matrices/Smik_Ste12_GSM123483-23636.txt_Extracted_mlpout_L8_3_1.mlp'

[motif_str1, motif_energy1]=read_bayesianReduce_mlp(file1);
[psam1,rel_w1]=motif_weight2p(motif_energy1);
IC1=p2informationCount(psam1)
core_energy1=IC1(:,2:8)
core_str1=core_str3 %try to make the same core motif as the Sbay 

[motif_str2, motif_energy2]=read_bayesianReduce_mlp(file2);
[psam2,rel_w2]=motif_weight2p(motif_energy2);
IC2=p2informationCount(psam2)
core_energy2=IC2(:,1:7)
core_str2=core_str3 %try to make the same core motif as the Sbay 

[motif_str3, motif_energy3]=read_bayesianReduce_mlp(file3);
[psam3,rel_w3]=motif_weight2p(motif_energy3);
IC3=p2informationCount(psam3)
core_energy3=IC3(:,3:8)
core_str3=core_str3 %try to make the same core motif as the Sbay 

%compute mean and error bar of the cor motif TGAAAC
clear mean_energy std_energy
for i=1:size(core_str3,2)
        if i<7
                mean_energy(:,i)=mean([core_energy1(:,i),core_energy2(:,i),core_energy3(:,i)],2);
                std_energy(:,i)=std([core_energy1(:,i),core_energy2(:,i),core_energy3(:,i)],0,2);
        else
                 mean_energy(:,i)=mean([core_energy1(:,i),core_energy2(:,i)],2);
                std_energy(:,i)=std([core_energy1(:,i),core_energy2(:,i)],0,2);
        end
end

%for each core motif plot error bar
hold on
clear plot_energy plot_error
chars = ['acgt'];
for i=1:size(std_energy,2)
        idx=findstr(strvcat(chars), core_str3(i) );
        plot_energy(i)=mean_energy(idx,i);
        plot_error(i)=std_energy(idx,i);
end
ee2=errorbar(1:7,plot_energy,plot_error,'rs-');
set(gca,'XTick',[1:7]);
set(gca,'XTickLabelMode','Manual');
set(gca,'XTickLabel',upper(char({'t','g','a','a','a','c','g'})));
axis([0 8 0 2])
record_mean_energy(2,:)=plot_energy;
record_std_energy(2,:)=plot_error;

%Make Sbay
clear motif_str1 motif_energy1 psam1 rel_w1 core_energy1
clear motif_str2 motif_energy2 psam2 rel_w2 core_energy2
clear motif_str3 motif_energy3 psam3 rel_w3 core_energy3

file1='multiple_yeast_out_for_support/matrices/Sbay_Ste12_GSM123337-23656.txt_Extracted_mlpout_L8_3_1.mlp'
file2='multiple_yeast_out_for_support/matrices/Sbay_Ste12_GSM123338-23633.txt_Extracted_mlpout_L8_3_1.mlp'
file3='multiple_yeast_out_for_support/matrices/Sbay_Ste12_GSM123335-23629.txt_Extracted_mlpout_L8_3_1.mlp'
%if it is reverse then change ACGT to TGCA

[motif_str1, motif_energy1]=read_bayesianReduce_mlp(file1);
[psam1,rel_w1]=motif_weight2p(motif_energy1);
IC1=p2informationCount(psam1)
core_energy1=IC1(:,7:-1:1)
core_str1=motif_str1(7:-1:1)
core_energy1_rev(1,:)=core_energy1(4,:);
core_energy1_rev(2,:)=core_energy1(3,:);
core_energy1_rev(3,:)=core_energy1(2,:);
core_energy1_rev(4,:)=core_energy1(1,:);
 

[motif_str2, motif_energy2]=read_bayesianReduce_mlp(file2);
[psam2,rel_w2]=motif_weight2p(motif_energy2);
IC2=p2informationCount(psam2)
core_energy2=IC2(:,7:-1:1)
core_str2=motif_str2(7:-1:1)
core_energy2_rev(1,:)=core_energy2(4,:);
core_energy2_rev(2,:)=core_energy2(3,:);
core_energy2_rev(3,:)=core_energy2(2,:);
core_energy2_rev(4,:)=core_energy2(1,:);

[motif_str3, motif_energy3]=read_bayesianReduce_mlp(file3);
[psam3,rel_w3]=motif_weight2p(motif_energy3);
IC3=p2informationCount(psam3)
core_energy3=IC3(:,2:8)
core_str3=motif_str3(2:8)


%compute mean and error bar of the cor motif TGAAAC
for i=1:4
	mean_energy(i,:)=(core_energy1_rev(i,:)+core_energy2_rev(i,:)+core_energy3(i,:))./3;
	std_energy(i,:)=std([core_energy1_rev(i,:); core_energy2_rev(i,:); core_energy3(i,:)],1)
end

%for each core motif plot error bar
chars = ['acgt'];
for i=1:size(std_energy,2)
	idx=findstr(strvcat(chars), core_str3(i) );
	plot_energy(i)=mean_energy(idx,i);
	plot_error(i)=std_energy(idx,i);	
end
record_mean_energy(3,:)=plot_energy;
record_std_energy(3,:)=plot_error;

ee1=errorbar(1:7,plot_energy,plot_error,'s-');
set(gca,'XTick',[1:7]);
set(gca,'XTickLabelMode','Manual');
set(gca,'XTickLabel',upper(char({'t','g','a','a','a','c','g'})));
axis([0 8 0 2])

legend('Scer','Smik','Sbay')
x1=xlabel('STE12 consensus motif')
y1=ylabel('Bits')
set(x1,'fontSize',15);
set(y1,'fontSize',15)
set(gca,'FontSize',15)
set(ee1,'LineWidth',2)
set(ee2,'LineWidth',2)
set(ee3,'LineWidth',2)
set(gca,'box','on')


figure(2)
bar(record_mean_energy')
legend('Scer','Smik','Sbay')

hold on
errorbar(1:7,record_mean_energy(2,:),record_std_energy(2,:),'o')
hold on
errorbar((1:7)+0.25,record_mean_energy(3,:),record_std_energy(3,:),'o')
set(gca,'XTick',[1:7]);
set(gca,'XTickLabelMode','Manual');
set(gca,'XTickLabel',upper(char({'t','g','a','a','a','c','g'})));
axis([0 8 0 2])

x1=xlabel('STE12 consensus motif')
y1=ylabel('Bits')
set(x1,'fontSize',15);
set(y1,'fontSize',15)
set(gca,'FontSize',15)
set(ee1,'LineWidth',2)
set(ee2,'LineWidth',2)
set(ee3,'LineWidth',2)
set(gca,'box','on')


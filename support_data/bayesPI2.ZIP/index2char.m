function [strings_p]=index2char(xx,L,oligos,oligos_p)
%Input is binary representation of sequence (0001,1000,)
%Output is string representation of sequence (acgt)
chars={'a','c','g','t'};

for j=1:size(xx,1)
	t_xx=xx(j,:);
	re_x=reshape(t_xx,4,L);
	tstrings=[];
	for i=1:L
		tstrings=[tstrings,chars{find(re_x(:,i))}];
	end
        strings_p(j)=oligos_p(strmatch(tstrings,oligos,'exact'));
end
strings_p=reshape(strings_p,length(strings_p),1);
	



function [e, edata, eprior] = wang_mlperr_lasso(net, x, t,nucleosome_t)
global isnucleosome
%MLPERR	Evaluate error function for 2-layer network.
%
%	Description
%	E = MLPERR(NET, X, T) takes a network data structure NET together
%	with a matrix X of input vectors and a matrix T of target vectors,
%	and evaluates the error function E. The choice of error function
%	corresponds to the output unit activation function. Each row of X
%	corresponds to one input vector and each row of T corresponds to one
%	target vector.
%
%	[E, EDATA, EPRIOR] = MLPERR(NET, X, T) additionally returns the data
%	and prior components of the error, assuming a zero mean Gaussian
%	prior on the weights with inverse variance parameters ALPHA and BETA
%	taken from the network data structure NET.
%
%	See also
%	MLP, MLPPAK, MLPUNPAK, MLPFWD, MLPBKP, MLPGRAD
%

%	Copyright (c) Ian T Nabney (1996-2001)
% This is a modificaiton of the original mlperr.m by Junbai Wang May 2007
%

% Check arguments for consistency
errstring = consist(net, 'mlp', x, t);
if ~isempty(errstring);
  error(errstring);
end
%[y, z, a] = wang_mlpfwd(net, x);
if isnucleosome
    [y, z, a] = wang_mlpfwdC_nucleosome(net, x',nucleosome_t);
else    
    [y, z, a] = wang_mlpfwdC(net, x');
end
edata = 0.5*sum(sum((y - t).^2));
[e, edata, eprior] = wang_errbayes_lasso(net, edata);

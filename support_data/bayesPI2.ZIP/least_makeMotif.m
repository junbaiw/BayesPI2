function motif_code=least_makeMotif(motif)
%make motif
chars = ['a', 'c', 'g', 't'];
%motif = 'gag'
motif_length = length(motif);
l=motif_length;
motif_code = zeros(1, motif_length);
for i=1:motif_length
  motif_code(i) = find(chars == motif(i));
end


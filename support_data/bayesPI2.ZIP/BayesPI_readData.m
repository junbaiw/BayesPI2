function [x,new_seq,new_seq_str,max_col,mean_new_nuc_t,new_t]=BayesPI_readData(fileexp,fileseq,L,max_loop,seed,nhidden,...
    out_fold,selection_percentage,pcutoff,fileann,filenucleosome,isreverse,isrepeat)
%Read expression data
global isnucleosome
[t1,t_cases1,t_vars1]=tblread2(fileexp,'\t');
t_vars1=strrep(cellstr(t_vars1),'_','');	%remove all the _ in ids
if isreverse==1
	disp('This is a reversed experiment!')
	t1=-t1;	
	%if the experiment is reverse designed
end 

if min(t1)<0
	t1=2.^t1;	%transform to real ratios 
end

%read features
if exist(fileann)
	for ii=1:size(t_vars1,1)
		new_t_vars1{ii}=strrep(t_vars1(ii,:),'-','');	
	end
	[fdata,fv,fc]=tblread2(fileann,'\t');
	telomere=fdata(:,strmatch('telomere',fv) );
	[newcc,aci,bci]= intersect(lower(deblank(new_t_vars1')),cellstr(lower(fc)));
	
	new_t_vars1=cellstr(t_vars1(aci,:));
	new_fc=cellstr(fc(bci,:));
	new_t1=t1(aci,:);
	new_telomere=telomere(bci);
	idx1=find(new_telomere==0);
	new_t1_2=new_t1(idx1,:);
        new_t_vars1_2=strvcat(new_t_vars1(idx1));	
	t1=[];
	t1=new_t1_2;
  	t_vars1=[];
	t_vars1=new_t_vars1_2;	
end

%remove NAN
idx_nan=find(~isnan(t1));
t0=t1(idx_nan,:);
t_cases=t_cases1;
t_vars0=t_vars1(idx_nan,:);

%select subset datasets
%[st,sti]=sort(t0,'descend');
[ost,osti]=sort(t0);    %sort in descend order
st=ost(end:-1:1);sti=osti(end:-1:1);

if isempty(selection_percentage)
       selection_percentage=1;
end
st_vars=t_vars0(sti,:);

%compute percent of genes has >= ratios
num_of_good=length(find(st>=2));
num_of_total=length(st);

%we define at least 0.1 percent of input data has ratios >=2
num_of_input=ceil(num_of_good/selection_percentage);
idx_gene_selection=1:length(st);
new_idx_gene=idx_gene_selection(1:ceil(num_of_total*selection_percentage)); %num_of_input);      %ceil(num_of_total*selection_percentage));
t=[]; t_vars=[];
t=st(new_idx_gene);
t_vars=st_vars(new_idx_gene,:);

%read sequence data
[gene_id,gene_seq,gene_seq_idx]=read_seq_fa(fileseq);
gene_id=strrep(gene_id,'_',''); %remove all the _ in the ids 
disp(['Select ', num2str(selection_percentage), ' of input data !']);

%take an intersection between sequence and expression data
if exist('intersect')>0
	[cc,ai,bi]=intersect(strvcat(lower(deblank(gene_id))),strvcat(lower(deblank(t_vars))),'rows');
	if prod(size(cc))<1 
		display('No match was found between sequences and experssion data! -try again');	 
		cc=[];
       		loop=1;
        	for i=1:length(gene_id)
			temp_gene_id=lower(deblank(gene_id{i}));
			idx_camma=findstr(temp_gene_id,';');
			temp_gene=temp_gene_id(1:idx_camma(1)-1);
			idx_space=findstr(temp_gene,char(9));
			if ~isempty(idx_space)
				temp_gg=temp_gene(idx_space(end)+1:end);
			else
				temp_gg=temp_gene;
			end
                	tp=strmatch(lower(deblank(temp_gg)),lower(deblank(t_vars)),'exact');
                	if ~isempty(tp)
                        	ai(loop)=i;
                		bi(loop)=tp(1);
                        	cc{loop}=temp_gg;
                        	loop=loop+1;
                	end
        	end


	end
else
	cc=[];
	loop=1;
	for i=1:length(gene_id)
        	tp=strmatch(lower(deblank(gene_id{i})),lower(deblank(t_vars)),'exact');
        	if ~isempty(tp)
                	ai(loop)=i;
               	bi(loop)=tp(1);
                	cc{loop}=lower(deblank(gene_id{i}));
                	loop=loop+1;
 	      	end
	end
end
new_id=cc;
if length(find(t(bi,:)<0))==0
	disp('Log transform of input data')
	new_t= log(t(bi,:));   %log2 transform of expression data if it is real ratios
	%hist(new_t)
else
	new_t=(t(bi,:));
	disp(' the input is Log transformed  data')
end

%Remove outlier there is a problem when nan appear in the input data
out_alpha=pcutoff/size(find(~isnan(new_t)),1) %0.000001 %0.001; %for some data we may need p=0.000001 for example bas1 and fhl1
out_rep=1;
[b,idx,outliers] = deleteoutliers(new_t,out_alpha,out_rep);
new_t=[];
nan_idx=find(~isnan(b));
new_t=exp(b(nan_idx));
disp(['Grubbs test to remove ', num2str(size(find(~isnan(outliers)),1)),' outliers ...' ]);
disp(['All input data are transformed back to Real ratios!']);

%remove NAN
t_new_id=strvcat(new_id);
new_id=[];
new_id=t_new_id(nan_idx,:);
t_new_seq=gene_seq_idx(ai,:);
new_seq=t_new_seq(nan_idx,:);
t_new_seq_str=gene_seq(ai);
new_seq_str=t_new_seq_str(nan_idx);
clear t_new_id t_new_seq t_new_seq_str b idx outliers cc ai bi t

%read nucleosome file
mean_new_nuc_t=[];
isnucleosome=0;
if ~isempty(filenucleosome)
    isnucleosome=1;
    [nuc_data,nuc_vars,nuc_cases]=tblread2(filenucleosome,'\t');
    for i=1:size(nuc_cases,1)
        temp=nuc_cases(i,:);
        idx=findstr(':',temp);
        temp_cases=temp(1:idx-1);    
        new_nuc_cases(i)=cellstr(lower(temp_cases));
    end
    disp('Read nucleosome data')
    [nuc_c,nuc_cia,nuc_cib]=intersect(new_nuc_cases,cellstr(deblank(lower(new_id))));
    len_nuc=length(nuc_c);
    disp(['Find ',num2str(len_nuc), ' of ',num2str(size(new_id,1)),' probes have nucleosome data']);
    t_new_id=new_id;
    new_id=[]; new_id=t_new_id(nuc_cib,:);
    t_new_t=new_t; new_t=[]; new_t=t_new_t(nuc_cib,:);
    t_new_seq=new_seq; new_seq=[]; new_seq=t_new_seq(nuc_cib,:);
    t_new_seq_str=new_seq_str; new_seq_str=[]; new_seq_str=t_new_seq_str(nuc_cib);
    new_nuc_t=nuc_data(nuc_cia,:);
    mean_new_nuc_t=[];
    for ki=1:size(new_nuc_t,1)
        temp=new_nuc_t(ki,:);
        temp_idx=[];
        temp_idx=find(~isnan(temp));
        mean_new_nuc_t(ki)=mean(temp(temp_idx));
    end
   % hist(new_nuc_t)
   % [cellstr(new_id),new_nuc_cases(nuc_cia)']
    clear t_new_id t_new_t t_new_seq t_new_seq_str
end
%%%%%
ndata = size(new_t,1);
max_col=max(find(sum(new_seq,1)));
x=new_seq(:,1:max_col); %gene_seq_idx;
disp(['Read: gene ',num2str(size(new_t,1)),'; sequence length ',num2str(max_col)])

%motif length
%for saving memory
%clear t1 t_cases1 t_vars1 gene_id gene_seq new_seq_str new_seq cc bi ai gene_seq_idx;%
